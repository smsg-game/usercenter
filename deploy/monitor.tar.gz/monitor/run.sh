#!/bin/sh
libpath=monitor.jar:etc
for jar in lib/*.jar;
  do
    libpath=$libpath:$jar
done

nohup java -Xms256M -Xmx1024M -cp $libpath com.easou.monitor.socket.server.MServer > /dev/null 2>&1 &
